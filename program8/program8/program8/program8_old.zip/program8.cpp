// 1410
// Program 8
// Student: Adrian Davila
// TA: Salah Taamneh
// Date: 4/1/2015
#include <iostream>
#include "Course.h"
#include <ctime>

using namespace std;

/*Size of the array can be adjusted in "Course.h"*/

int main(){
	srand(time(NULL));
	Course courseClass3;
	courseClass3.print();
	return 0;
}